//*****************************************************************************
//*
//* Explorer 16 Development Board Demo Program for MCP4XXXDM-PTPLS Daughter 
//* Board (MCP4XXXDM-PTPLS)
//*
//*****************************************************************************
//* FileName:        MCP4XXXDM PTPLS.c
//* Dependencies:    system.h
//* Processor:       PIC24FJ128GA010
//* Compiler:        MPLAB C30 v2.04 or later
//* Linker:          MPLAB LINK30
//* Company:         Microchip Technology Incorporated
//*
//* Software License Agreement
//*
//* The software supplied herewith by Microchip Technology Incorporated
//* (the "Company") is intended and supplied to you, the Company's
//* customer, for use solely and exclusively with products manufactured
//* by the Company. 
//*
//* The software is owned by the Company and/or its supplier, and is 
//* protected under applicable copyright laws. All rights are reserved. 
//* Any use in violation of the foregoing restrictions may subject the 
//* user to criminal sanctions under applicable laws, as well as to 
//* civil liability for the breach of the terms and conditions of this 
//* license.
//*
//* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES, 
//* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
//* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
//* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT, 
//* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR 
//* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
//*
//*
//* Author           Date   Rev     Comment
//*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//* Mark Palmer      XXXX   A01     Initial Release of Demo Program	
//*****************************************************************************
//*
//*  MAX4582L Decode:
//*    B      A     
//*  (RD14) (RD15)  Y=pin    Y=Voltage
//*    1      1      Y3       9.0V
//*    1      0      Y2       GND
//*    0      1      Y1       3.3V
//*    0      0      Y0       5.0V
//*
//*
//*
//*
//*
//*
//*****************************************************************************
//*

#include "system.h"

// Setup configuration bits
_CONFIG1( JTAGEN_OFF & GCP_OFF & GWRP_OFF & COE_OFF & FWDTEN_OFF & ICS_PGx2) 
_CONFIG2( FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMOD_HS & FNOSC_PRI)


#define     DISP_MAX        2
#define     DISP_HELLO      0
#define     DISP_CLOCK      2
#define     DISP_VOLTAGE    1

unsigned char _display_state;

int main(void)
{
    unsigned char WiperValue;    // 8-bit value
    unsigned char Pot0_ADDR_CMD; // 8-bit value
    unsigned char Pot1_ADDR_CMD; // 8-bit value
    unsigned char ADDR_CMD_Byte; // 8-bit value
    unsigned char SPI_RX_Byte;   // 8-bit value
    unsigned char SPI_READ_MSB;  // 8-bit value
    unsigned char SPI_READ_LSB;  // 8-bit value


                               // Select desired CS voltage
    PORTD &= 0x3FFF;           // Bitwise AND on PORTD (RD15:RD14 = 00)
    TRISD &= 0x3FFF;           // Bitwise AND on TRISD (TRISD15:TRISD14 = 00)
                               //   RD15:RD14 are outputs, --> CS = 5.0V


    TRISBbits.TRISB2 = 0;      // Make RB2 and Output
    PORTBbits.RB2 = 0;         // Force RB2 Low  (ENABLE signal, Low = Enabled)


    TRISFbits.TRISF1 = 0;      // Make RF1 and Output
    PORTFbits.RF1 = 1;         // Force RF1 High

    TRISFbits.TRISF0 = 0;      // Make RF0 and Output
    PORTFbits.RF0 = 1;         // Force RF0 High


    TRISFbits.TRISF6 = 0;      // Make RF6 and Output
    PORTFbits.RF6 = 1;         // Force RF6 High

    TRISFbits.TRISF7 = 0;      // Make RF7 and Output
    PORTFbits.RF7 = 1;         // Force RF7 High

    TRISFbits.TRISF8 = 0;      // Make RF8 and Output
    PORTFbits.RF8 = 1;         // Force RF8 High


    TRISGbits.TRISG6 = 0;      // Make RG6 and Output
    PORTGbits.RG6 = 1;         // Force RG6 High

    TRISGbits.TRISG7 = 0;      // Make RG7 and Output
    PORTGbits.RG7 = 1;         // Force RG7 High

    TRISGbits.TRISG8 = 0;      // Make RG8 and Output
    PORTGbits.RG8 = 1;         // Force RG8 High



    WiperValue = 0;            // This is the initial value of the wiper


    // Start from displaying of PIC24 banners
    _display_state = DISP_HELLO;

    // Setup PortA IOs as digital
    AD1PCFG = 0xffff;

    // Setup SPI to communicate to EEPROM
    SPIMPolInit();

	// Setup the LCD
	mLCDInit();

	// Setup the banner processing
	BannerStart();

//    OpenSPI1(0x013D,0x0000,0x8000);  // 8-bit Mode, CKE = 0, SMP = 0, CKP = 0
//                                     //   SPRE2:0 = 111, PPRE1:0 = 01, SPIEN = 1

    OpenSPI2(0x013D,0x0000,0x8000);  // 8-bit Mode, CKE = 0, SMP = 0, CKP = 0
                                     //   SPRE2:0 = 111, PPRE1:0 = 01, SPIEN = 1

    ADDR_CMD_Byte = 0b00010000;      // Write Vol Wiper 1, D8 = 0

    if (PORTDbits.RD6)
    {
        Nop(); 
        while (1) 
        {
            PORTD |= 0x4000;     // Bitwise OR on PORTD (RD15:RD14 = 01)
                                 //   --> CS = Vss (can communicate with MCP4xxx)
                                 //   Normal Voltage commands

            SPI_RX_Byte = SPI2BUF;         // Clear SPIRBF bit

            // Write "WiperValue" to Pot1

            while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                           // If YES, wait here

            WriteSPI2(ADDR_CMD_Byte);      // Write the ADDR_CMD_Byte
            while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                           // If YES, wait here
            WriteSPI2(WiperValue);         // WiperValue

            while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                           // If NO, wait here

            SPI_RX_Byte = SPI2BUF;         // Clear SPIRBF bit

            while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                           // If NO, wait here

            PORTD &= 0x3FFF;     // Bitwise AND on PORTD (RD15:RD14 = 00)
                                 //   --> CS = 5.0V 

            WiperValue = WiperValue + 1; // Increment Temp

            if (SRbits.C)                //
            {
                PORTD &= 0x3FFF;     
                WiperValue = 0;          // 
                ADDR_CMD_Byte = 0b00010001;    // Write Vol Wiper 1, D8 = 0
            }
            else
            {
                if (ADDR_CMD_Byte == 0b00010001)
                {
                    WiperValue = 0;            //
                }
                ADDR_CMD_Byte = 0b00010000;    // Write Vol Wiper 1, D8 = 0   
            }
        } // End of while(1)...
    } // end of if

    else
    {
        while (! PORTDbits.RD6);    // Wait for Switch 3 (RD6) to be released
        Nop();
        while (1) 
        {

            while (PORTDbits.RD7 == 0)  // This loop will Increment the Wiper
            {
                PORTD |= 0x4000;     // Bitwise OR on PORTD (RD15:RD14 = 01)
                                     //   --> CS = Vss (can communicate with MCP4xxx)
                                     //   Normal Voltage commands

                SPI_RX_Byte = SPI2BUF;         // Clear SPIRBF bit

                // Write Increment Command to Volatile Pot1 register

                while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                               // If YES, wait here

                ADDR_CMD_Byte = 0b00010100;    // Increment Vol Wiper 1
                WriteSPI2(ADDR_CMD_Byte);      // Write the ADDR_CMD_Byte

                while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                               // If NO, wait here
                SPI_RX_Byte = SPI2BUF;         // Clear SPIRBF bit

                PORTD &= 0x3FFF;     // Bitwise AND on PORTD (RD15:RD14 = 00)
                                     //   --> CS = 5.0V 

                __delay32(500000);   // Delay 100ms at 20MHz (500,000 cycles)
            }

            while (PORTDbits.RD13 == 0)  // This loop will Decrement the Wiper
            {
                PORTD |= 0x4000;     // Bitwise OR on PORTD (RD15:RD14 = 01)
                                     //   --> CS = Vss (can communicate with MCP4xxx)
                                     //   Normal Voltage commands

                SPI_RX_Byte = SPI2BUF;         // Clear SPIRBF bit

                // Write Decrement Command to Volatile Pot1 register

                while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                               // If YES, wait here

                ADDR_CMD_Byte = 0b00011000;    // Decrement Vol Wiper 1
                WriteSPI2(ADDR_CMD_Byte);      // Write the ADDR_CMD_Byte

                while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                               // If NO, wait here
                SPI_RX_Byte = SPI2BUF;         // Clear SPIRBF bit

                PORTD &= 0x3FFF;     // Bitwise AND on PORTD (RD15:RD14 = 00)
                                     //   --> CS = 5.0V 

                __delay32(500000);   // Delay 1ms at 20MHz (500,000 cycles)
            }

            if (PORTAbits.RA7 == 0)      // Write Volatile Wiper value
            {                            //   to Non-Volatile Wiper Register
                Nop();
                Nop();
                PORTD |= 0xC000;     // Bitwise OR on PORTD (RD15:RD14 = 11)
                                     //   --> CS = Vihh (can communicate with MCP4xxx)
                                     //   Higg Voltage commands

                SPI_RX_Byte = SPI2BUF;         // Clear SPIRBF bit

                // Read Command of Volatile Pot1 register

                while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                               // If YES, wait here

                ADDR_CMD_Byte = 0b00011111;    // Read Vol Wiper 1

                WriteSPI2(ADDR_CMD_Byte);      // Write the ADDR_CMD_Byte
                while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                               // If YES, wait here
                WiperValue = 0xFF;             // This is a Dummy value to get 16 clocks.
                WriteSPI2(WiperValue);         // WiperValue

                while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                               // If NO, wait here

                SPI_READ_MSB = SPI2BUF;        // Read MSB and Clear SPIRBF bit

                while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                               // If NO, wait here

                SPI_READ_LSB = SPI2BUF;        // Read LSB and Clear SPIRBF bit

                PORTD &= 0x3FFF;     // Bitwise AND on PORTD (RD15:RD14 = 00)
                                     //   --> CS = 5.0V 

                Nop();
                Nop();

                PORTD |= 0xC000;     // Bitwise OR on PORTD (RD15:RD14 = 11)
                                     //   --> CS = Vihh (can communicate with MCP4xxx)
                                     //   Higg Voltage commands

                // Write value Read to NV Pot1 register

                while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                               // If YES, wait here

                ADDR_CMD_Byte = 0b00110000;    // Write Non-Vol Wiper 1

                SPI_READ_MSB = SPI_READ_MSB & 0x01;   // Only want LSb of register (MSb of 9-bit Data)
                ADDR_CMD_Byte = ADDR_CMD_Byte | SPI_READ_MSB; // Determines if LSb is 0 or 1

                WriteSPI2(ADDR_CMD_Byte);      // Write the ADDR_CMD_Byte
                while (SPI2STATbits.SPITBF);   // Is the SPI Transfer Buffer full ?
                                               // If YES, wait here
                WriteSPI2(SPI_READ_LSB);       // Write bits 7-0 of Data (9-bit data)

                while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                               // If NO, wait here

                SPI_READ_MSB = SPI2BUF;        // Read MSB and Clear SPIRBF bit

                while ( ! SPI2STATbits.SPIRBF);   // Is the SPI Receive Buffer full ?
                                               // If NO, wait here

                SPI_READ_LSB = SPI2BUF;        // Read LSB and Clear SPIRBF bit

                PORTD &= 0x3FFF;     // Bitwise AND on PORTD (RD15:RD14 = 00)
                                     //   --> CS = 5.0V 
                                     // Starts Non-Volatile Programming Memory Cycle
                __delay32(50000);    // Delay 10ms at 20MHz (50,000 cycles)


            }

        } // End of while(1)... 
    }  // End of Else condition

} // End of main()...
