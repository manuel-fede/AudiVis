#if defined(__PIC24F__)
#include <p24Fxxxx.h>
#endif
#include "spi.h"

/********************************************************************
*     Function Name :  CloseSPI2                                    *
*     Description   :  This routine disables the SPI module and its *
*                       interrupt bits.                             * 
*     Parameters    :  None                                         *
*     Return Value  :  None                                         *
********************************************************************/
#ifdef _SPI_V2_2

void CloseSPI2( )
{
      IEC2bits.SPI2IE = 0;      /* Disable the Interrupt bit in the 
                                Interrupt Enable Control Register */
      SPI2STATbits.SPIEN = 0;   /* Disable the module. All pins controlled
                                by PORT Functions */
      IFS2bits.SPI2IF = 0;      /* Disable the Interrupt flag bit in the 
                                Interrupt Flag Control Register */    
}

#else
#warning "Does not build on this target"
#endif
