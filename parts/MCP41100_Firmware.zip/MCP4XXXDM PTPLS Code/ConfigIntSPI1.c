#if defined(__PIC24F__)
#include <p24Fxxxx.h>
#endif
#include "spi.h"

/************************************************************************
*     Function Name :  ConfigIntSPI1                                    *
*     Description   :  This Function Configures Interrupt and sets      *
*                      Interrupt Priority                               *
*     Parameters    :  unsigned int config                              *
*     Return Value  :  None                                             *
************************************************************************/
#ifdef _SPI_V2_1

void ConfigIntSPI1( unsigned int config)
{
    IFS0bits.SPI1IF = 0;                   /* Clear IF bit */
    IPC2bits.SPI1IP = (config &0x0007);    /* Assign interrupt priority */
    IEC0bits.SPI1IE = (config &0x0008)>>3; /* Interrupt Enable/Disable bit */
}

#else
#warning "Does not build on this target"
#endif
