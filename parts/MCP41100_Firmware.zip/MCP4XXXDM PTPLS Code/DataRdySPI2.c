#if defined(__PIC24F__)
#include <p24Fxxxx.h>
#endif
#include "spi.h"

/********************************************************************
*     Function Name : DataRdySPI2                                   *
*     Description   : Determine if there is a byte/word to be read  *
*                     from the SPIBUF register.                     *
*     Parameters    : None                                          *
*     Return Value  : status bit to indicate if RBF = 1 else 0      *
********************************************************************/

/* The following devices support SPI2 */
#ifdef _SPI_V2_2

char DataRdySPI2()
{   
    return SPI2STATbits.SPIRBF; /* return RBF bit status */
}

#else
#warning "Does not build on this target"
#endif
