#if defined(__PIC24F__)
#include <p24Fxxxx.h>
#endif
#include "spi.h"

/************************************************************************
*     Function Name :  ConfigIntSPI2                                    *
*     Description   :  This Function Configures Interrupt and sets      *
*                      Interrupt Priority                               *
*     Parameters    :  unsigned int config                              *
*     Return Value  :  None                                             *
************************************************************************/
#ifdef _SPI_V2_2

void ConfigIntSPI2( unsigned int config)
{
    IFS2bits.SPI2IF = 0;                 /* Clear IF bit */
    IPC8bits.SPI2IP=(config &0x0007);    /* Assign interrupt priority */
    IEC2bits.SPI2IE=(config &0x0008)>>3; /* Interrupt Enable/Disable bit */
}

#else
#warning "Does not build on this target"
#endif
