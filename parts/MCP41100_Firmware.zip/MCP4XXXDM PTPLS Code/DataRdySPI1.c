#if defined(__PIC24F__)
#include <p24Fxxxx.h>
#endif
#include "spi.h"

/********************************************************************
*     Function Name : DataRdySPI1                                   *
*     Description   : Determine if there is a byte/word to be read  *
*                     from the SPIBUF register.                     *
*     Parameters    : None                                          *
*     Return Value  : status bit to indicate if RBF = 1 else 0      *
********************************************************************/
#ifdef _SPI_V2_1

char DataRdySPI1()
{   
    return SPI1STATbits.SPIRBF; /* return the RBF bit status */
}

#else
#warning "Does not build on this target"
#endif
